export default () => (
	<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" preserveAspectRatio="xMidYMid meet" viewBox="0 0 24 24">
		<circle cx="12" cy="12" r="11" fillOpacity="0.2" />
		<path d="M 12 1 C 6 1 1 6 1 12 C 1 18 6 23 12 23 C 18 23 23 18 23 12 C 23 6 18 1 12 1 z M 12 3 C 17 3 21 7 21 12 C 21 17 17 21 12 21 C 7 21 3 17 3 12 C 3 7 7 3 12 3 z M 12 8.333 C 10 8.333 8.333 10 8.333 12 C 8.333 14 10 15.667 12 15.667 C 14 15.667 15.667 14 15.667 12 C 15.667 10 14 8.333 12 8.333 z" />
	</svg>
);
