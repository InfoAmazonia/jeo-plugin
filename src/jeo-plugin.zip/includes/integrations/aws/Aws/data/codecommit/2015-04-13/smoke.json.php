<?php
// This file was auto-generated from sdk-root/src/data/codecommit/2015-04-13/smoke.json
return [ 'version' => 1, 'defaultRegion' => 'us-west-2', 'testCases' => [ [ 'operationName' => 'ListRepositories', 'input' => [], 'errorExpectedFromService' => false, ], [ 'operationName' => 'ListBranches', 'input' => [ 'repositoryName' => 'fake-repo', ], 'errorExpectedFromService' => true, ], ],];
